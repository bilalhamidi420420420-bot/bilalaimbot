CryptoProBot Backend - Flask API (see app.py)
